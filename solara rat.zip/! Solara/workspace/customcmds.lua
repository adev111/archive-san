--Here you can add custom commands using the following format: 

 https://media.discordapp.net/attachments/980897248441417781/1009947488054153276/unknown.png